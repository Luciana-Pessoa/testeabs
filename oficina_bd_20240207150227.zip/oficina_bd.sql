-- MySQL dump 10.13  Distrib 5.7.38, for Linux (x86_64)
--
-- Host: localhost    Database: oficina_bd
-- ------------------------------------------------------
-- Server version	5.7.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (2,'Lubrificantes'),(3,'Peças Carro'),(6,'Óleos'),(7,'Acessórios'),(8,'Lanternagem'),(9,'Pintura');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (5,'ATMOSFERA VALADARES','840.985.652-92','(84) 89151-6165','atmosfera@gmail.com','RUA A, 120, BAIRR B, BETIM MG','2024-02-02'),(6,'LUCIANA PESSOA','654.184.891-65','(65) 49849-5265','LUCIANA@GMAIL.COM','RUA B, 180, BAIRR C, BETIM MG','2024-02-02'),(7,'ALGORITMO SANTOS','065.941.645-16','(31) 84962-9846','SANTOS@GMAIL.COM','RUA C, 280, BAIRRO D, BETIM MG','2024-02-02');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comissoes`
--

DROP TABLE IF EXISTS `comissoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comissoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valor` decimal(8,2) NOT NULL,
  `mecanico` varchar(20) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `id_servico` int(11) NOT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comissoes`
--

LOCK TABLES `comissoes` WRITE;
/*!40000 ALTER TABLE `comissoes` DISABLE KEYS */;
INSERT INTO `comissoes` VALUES (22,285.00,'877.777.777-77','Serviço',51,'2024-02-07'),(23,135.00,'877.777.777-77','Serviço',52,'2024-02-07');
/*!40000 ALTER TABLE `comissoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compras`
--

DROP TABLE IF EXISTS `compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `produto` int(11) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `funcionario` varchar(20) NOT NULL,
  `data` date NOT NULL,
  `id_conta` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras`
--

LOCK TABLES `compras` WRITE;
/*!40000 ALTER TABLE `compras` DISABLE KEYS */;
/*!40000 ALTER TABLE `compras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contas_pagar`
--

DROP TABLE IF EXISTS `contas_pagar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contas_pagar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(50) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `funcionario` varchar(20) NOT NULL,
  `data` date NOT NULL,
  `data_venc` date NOT NULL,
  `pago` varchar(5) NOT NULL,
  `imagem` varchar(100) DEFAULT NULL,
  `fornecedor` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contas_pagar`
--

LOCK TABLES `contas_pagar` WRITE;
/*!40000 ALTER TABLE `contas_pagar` DISABLE KEYS */;
INSERT INTO `contas_pagar` VALUES (48,'Cemig',580.00,'866.655.555-90','2024-02-02','2024-02-02','Não','favicon.png',0),(49,'Copasa',320.00,'866.655.555-90','2024-02-02','2024-02-02','Não','images.jpeg',0),(50,'Comissão',285.00,'877.777.777-77','2024-02-07','2024-02-07','Não',NULL,0),(51,'Comissão',135.00,'877.777.777-77','2024-02-07','2024-02-07','Não',NULL,0);
/*!40000 ALTER TABLE `contas_pagar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contas_receber`
--

DROP TABLE IF EXISTS `contas_receber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contas_receber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(50) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `adiantamento` decimal(8,2) DEFAULT NULL,
  `mecanico` varchar(20) NOT NULL,
  `cliente` varchar(20) NOT NULL,
  `funcionario` varchar(20) DEFAULT NULL,
  `data` date NOT NULL,
  `pago` varchar(5) NOT NULL,
  `id_servico` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contas_receber`
--

LOCK TABLES `contas_receber` WRITE;
/*!40000 ALTER TABLE `contas_receber` DISABLE KEYS */;
INSERT INTO `contas_receber` VALUES (38,'Orçamento',1751.20,0.00,'877.777.777-77','654.184.891-65',NULL,'2024-02-07','Não',22),(39,'Orçamento',1.20,0.00,'877.777.777-77','840.985.652-92',NULL,'2024-02-07','Não',23);
/*!40000 ALTER TABLE `contas_receber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controles`
--

DROP TABLE IF EXISTS `controles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `controles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `veiculo` int(11) NOT NULL,
  `mecanico` varchar(20) NOT NULL,
  `data` date NOT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controles`
--

LOCK TABLES `controles` WRITE;
/*!40000 ALTER TABLE `controles` DISABLE KEYS */;
INSERT INTO `controles` VALUES (10,7,'877.777.777-77','2024-02-07','Lanternagem'),(11,9,'877.777.777-77','2024-02-07','4 Serviços'),(12,8,'877.777.777-77','2024-02-07','');
/*!40000 ALTER TABLE `controles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fornecedores`
--

DROP TABLE IF EXISTS `fornecedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fornecedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `tipo_pessoa` varchar(20) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fornecedores`
--

LOCK TABLES `fornecedores` WRITE;
/*!40000 ALTER TABLE `fornecedores` DISABLE KEYS */;
INSERT INTO `fornecedores` VALUES (1,'Marcos Souza','Jurídica','55.555.555/5558-88','(55) 55555-5555','marcos@hotmail.com','Rua A'),(3,'Paloma Campos','Física','585.555.555-55','(66) 66666-6666','paloma@hotmail.com','Rua D'),(5,'Atmosfera Freios','Jurídica','65.411.651/9841-65','(62) 65295-2651','atmosfera@gmail.com','RUA A, 120, BAIRR B, BETIM MG'),(6,'ALGORITMO SANTOS','Jurídica','64.984.198/1941-49','(84) 98126-5126','SANTOS@GMAIL.COM','');
/*!40000 ALTER TABLE `fornecedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mecanicos`
--

DROP TABLE IF EXISTS `mecanicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mecanicos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `endereco` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mecanicos`
--

LOCK TABLES `mecanicos` WRITE;
/*!40000 ALTER TABLE `mecanicos` DISABLE KEYS */;
INSERT INTO `mecanicos` VALUES (1,'Marcela Silva','788.888.888-60','(88) 88888-8888','marcela@hotmail.com','Rua A'),(5,'Mecânico Teste','877.777.777-77','(77) 77777-7777','mecanico@hotmail.com','Rua S');
/*!40000 ALTER TABLE `mecanicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimentacoes`
--

DROP TABLE IF EXISTS `movimentacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movimentacoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(20) NOT NULL,
  `descricao` varchar(50) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `funcionario` varchar(20) NOT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimentacoes`
--

LOCK TABLES `movimentacoes` WRITE;
/*!40000 ALTER TABLE `movimentacoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `movimentacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orc_prod`
--

DROP TABLE IF EXISTS `orc_prod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orc_prod` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orcamento` int(11) NOT NULL,
  `produto` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orc_prod`
--

LOCK TABLES `orc_prod` WRITE;
/*!40000 ALTER TABLE `orc_prod` DISABLE KEYS */;
INSERT INTO `orc_prod` VALUES (24,2,14),(25,5,13),(26,5,14),(27,5,8),(28,2,9),(29,2,7),(32,7,16),(33,7,9),(34,9,15),(35,9,10),(36,15,7),(37,15,13),(38,18,15),(39,18,13),(42,19,13),(44,19,14),(45,19,14),(46,20,15),(47,20,9),(48,21,7),(49,22,16),(50,22,10);
/*!40000 ALTER TABLE `orc_prod` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orc_serv`
--

DROP TABLE IF EXISTS `orc_serv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orc_serv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orcamento` int(11) NOT NULL,
  `servico` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orc_serv`
--

LOCK TABLES `orc_serv` WRITE;
/*!40000 ALTER TABLE `orc_serv` DISABLE KEYS */;
INSERT INTO `orc_serv` VALUES (1,19,7),(2,19,6),(4,19,1),(6,18,7),(7,20,7),(8,20,6),(9,21,2),(10,22,6),(11,22,5),(12,22,7),(13,22,8);
/*!40000 ALTER TABLE `orc_serv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orcamentos`
--

DROP TABLE IF EXISTS `orcamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orcamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente` varchar(20) NOT NULL,
  `veiculo` int(11) NOT NULL,
  `descricao` text NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `servico` int(11) NOT NULL,
  `data` date NOT NULL,
  `data_entrega` date NOT NULL,
  `garantia` int(11) NOT NULL,
  `mecanico` varchar(20) NOT NULL,
  `obs` text NOT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orcamentos`
--

LOCK TABLES `orcamentos` WRITE;
/*!40000 ALTER TABLE `orcamentos` DISABLE KEYS */;
INSERT INTO `orcamentos` VALUES (22,'654.184.891-65',9,'Serviço de pintura e lanternagem na parte frontal do veiculo',1.20,8,'2024-02-02','2024-02-02',15,'877.777.777-77','veiculo com arranhao na porta  lateral esquerda. ','Aprovado'),(23,'840.985.652-92',8,'PORTA DIANTEIRA ESQUERDA, REPARO.',1.20,0,'2024-02-07','2024-02-06',15,'877.777.777-77','VEICULO COM AVARIA NO CAPO. ','Aprovado');
/*!40000 ALTER TABLE `orcamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `os`
--

DROP TABLE IF EXISTS `os`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `os` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(50) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `mecanico` varchar(20) NOT NULL,
  `cliente` varchar(20) NOT NULL,
  `data_entrega` date NOT NULL,
  `concluido` varchar(5) NOT NULL,
  `valor_mao_obra` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `veiculo` int(11) NOT NULL,
  `garantia` int(11) DEFAULT NULL,
  `obs` text NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `id_orc` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `os`
--

LOCK TABLES `os` WRITE;
/*!40000 ALTER TABLE `os` DISABLE KEYS */;
INSERT INTO `os` VALUES (51,'Lanternagem',950.00,'877.777.777-77','065.941.645-16','2024-02-07','Sim',950.00,'2024-02-07',7,15,'RECUPERAÇÃO LATERAL DO VEICULO','Serviço',NULL),(52,'Pintura',450.00,'877.777.777-77','065.941.645-16','2024-02-07','Sim',450.00,'2024-02-07',7,15,'PINTURA DA LATERAL','Serviço',NULL),(53,'4 Serviços',1751.20,'877.777.777-77','654.184.891-65','2024-02-02','Não',1.20,'2024-02-07',9,15,'veiculo com arranhao na porta  lateral esquerda. ','Orçamento',22),(54,'',1.20,'877.777.777-77','840.985.652-92','2024-02-06','Não',1.20,'2024-02-07',8,15,'VEICULO COM AVARIA NO CAPO. ','Orçamento',23);
/*!40000 ALTER TABLE `os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produtos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(80) NOT NULL,
  `categoria` int(11) NOT NULL,
  `fornecedor` int(11) NOT NULL,
  `valor_compra` decimal(8,2) NOT NULL,
  `valor_venda` decimal(8,2) NOT NULL,
  `estoque` int(11) NOT NULL,
  `descricao` text,
  `imagem` varchar(100) DEFAULT NULL,
  `nivel_min` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (4,'Bateria',3,3,250.00,350.00,5,'A Bateria,é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas....','bateria.jpg',12),(7,'Correia Dentada',3,3,150.00,200.00,6,'A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas q','correia-dentada.jpg',0),(8,'Óleo Pneu Pretinho',6,1,25.00,35.00,5,'As principais características dos óleos lubrificantes são a viscosidade, o índice de viscosidade (IV) e a densidade. A viscosidade mede a dificuldade com que o óleo escorre (escoa).','pneu-pretinho.jpg',0),(9,'Óleo Lubrificante',2,1,20.00,35.00,11,'Linha de Lubrificação Aeronáutica Completa, você encontra na Lubvap. Melhores Preços, Qualidade Comprovada, Atendimento Personalizado, e muito mais, Confira. Atendimento 24h. Produto a pronta entrega. Melhor preço. Garantia de eficiência. Marcas: Rocol, A','oleo.jpg',0),(10,'Cabo de Ignição',3,1,250.00,300.00,10,'A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.','cabo-de-ignicao.jpg',9),(11,'Calota Aro 13',3,1,120.00,220.00,10,'A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.','calota-aro13.jpg',6),(12,'Capa Proteção',7,1,100.00,120.00,14,'A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.','capa-protecao.jpg',10),(13,'Embreagem',3,1,350.00,450.00,13,'A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.','embreagem.jpg',10),(14,'Faról',3,3,250.00,300.00,-2,'A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.','farol-de-carro.jpg',8),(15,'Freio Disco',3,3,250.00,300.00,-5,'A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.','freio-de-disco.jpg',7),(16,'ParaChoque Dianteiro',3,1,350.00,500.00,17,'A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.A correia dentada, também chamada de correia de distribuição, é uma peça matreira. Além de não dar sinais evidentes de desgaste ou pistas de que algo está mal, ela mantém ocultas na sua parte interna, composta por pequenos dentes de borracha, as mazelas que resultam da fricção constante pelo movimento de tração.','parachoque-dianteiro.jpg',8),(19,'Painel',3,1,500.00,800.00,7,'painel dianteiro','sem-foto.jpg',12);
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recepcionistas`
--

DROP TABLE IF EXISTS `recepcionistas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recepcionistas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recepcionistas`
--

LOCK TABLES `recepcionistas` WRITE;
/*!40000 ALTER TABLE `recepcionistas` DISABLE KEYS */;
INSERT INTO `recepcionistas` VALUES (1,'Paulo Campos','866.655.555-55','(00) 00000-0000','paulo@hotmail.com','Rua A'),(3,'Recepcionista Teste','444.444.444-44','(44) 44444-4444','recep@hotmail.com','Rua A');
/*!40000 ALTER TABLE `recepcionistas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retornos`
--

DROP TABLE IF EXISTS `retornos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `retornos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `veiculo` int(11) NOT NULL,
  `data_serv` date NOT NULL,
  `data_contato` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retornos`
--

LOCK TABLES `retornos` WRITE;
/*!40000 ALTER TABLE `retornos` DISABLE KEYS */;
INSERT INTO `retornos` VALUES (1,7,'2024-02-07','2024-02-07');
/*!40000 ALTER TABLE `retornos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicos`
--

DROP TABLE IF EXISTS `servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `valor` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicos`
--

LOCK TABLES `servicos` WRITE;
/*!40000 ALTER TABLE `servicos` DISABLE KEYS */;
INSERT INTO `servicos` VALUES (8,'Lanternagem',950.00),(9,'Pintura',450.00);
/*!40000 ALTER TABLE `servicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(30) NOT NULL,
  `nivel` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Marcela Silva','788.888.888-60','marcela@hotmail.com','123','mecanico'),(2,'Administrador','000.000.000-00','hvfadvocacia@gmail.com','123','admin'),(3,'Paulo Campos','866.655.555-90','paulo@hotmail.com','123','recep'),(5,'Recepcionista Teste','444.444.444-44','recep@hotmail.com','123','recep'),(10,'Mecânico Teste','877.777.777-77','mecanico@hotmail.com','123','mecanico');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `veiculos`
--

DROP TABLE IF EXISTS `veiculos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `veiculos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `marca` varchar(30) NOT NULL,
  `modelo` varchar(30) NOT NULL,
  `cor` varchar(30) NOT NULL,
  `placa` varchar(20) NOT NULL,
  `ano` int(11) NOT NULL,
  `km` int(11) NOT NULL,
  `cliente` varchar(20) NOT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `veiculos`
--

LOCK TABLES `veiculos` WRITE;
/*!40000 ALTER TABLE `veiculos` DISABLE KEYS */;
INSERT INTO `veiculos` VALUES (7,'FIAT','MOBI','PRETO','PHF-7B02',2020,52000,'065.941.645-16','2024-02-02'),(8,'GM','ONIX','CINZA','ASD-8575',2018,60220,'840.985.652-92','2024-02-02'),(9,'FORD','KA 1.0','VERMELHO','ASD-8569',2021,35820,'654.184.891-65','2024-02-02');
/*!40000 ALTER TABLE `veiculos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendas`
--

DROP TABLE IF EXISTS `vendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `produto` int(11) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `funcionario` varchar(20) NOT NULL,
  `data` date NOT NULL,
  `id_orc` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendas`
--

LOCK TABLES `vendas` WRITE;
/*!40000 ALTER TABLE `vendas` DISABLE KEYS */;
INSERT INTO `vendas` VALUES (1,16,500.00,'877.777.777-77','2024-02-07',22),(2,10,300.00,'877.777.777-77','2024-02-07',22);
/*!40000 ALTER TABLE `vendas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'oficina_bd'
--

--
-- Dumping routines for database 'oficina_bd'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-07 15:02:27
